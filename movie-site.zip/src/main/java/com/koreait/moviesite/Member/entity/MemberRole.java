package com.koreait.moviesite.Member.entity;

public enum MemberRole {
    USER,
    ADMIN
}
