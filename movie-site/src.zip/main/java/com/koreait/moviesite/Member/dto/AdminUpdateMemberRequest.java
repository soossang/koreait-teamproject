package com.koreait.moviesite.Member.dto;

public record AdminUpdateMemberRequest(
        Boolean active
) {}
